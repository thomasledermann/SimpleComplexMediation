# =========================================================================================================
# Ledermann, T., & Macho, S. Assessing mediation in simple and complex models
# =========================================================================================================
#
# Code for a mediation model with two initial variables
# Author: Thomas Ledermann
#
# =========================================================================================================
# Data: Marital Instability Over the Life Course (Booth, Johnson, Amato, & Rogers, 2010)
# "IncomeR","IncomeP","sEsteem","happy" = X1-X2 -> M -> Y
# =========================================================================================================

#source('http://openmx.psyc.virginia.edu/getOpenMx.R')

datafile <- 'C:/Users/DataVarSel.csv'
data <- read.csv(datafile, header = TRUE, sep = ",")
head(data)
nrow(data)

library(OpenMx)

myModel <- mxModel(name = "Mediation Model", type = "RAM", mxData(observed = data,type = "raw"),
  manifestVars = c("IncomeR","IncomeP","sEsteem","happy"),
  mxPath(           # Variances
    from = c("IncomeR","IncomeP","sEsteem","happy"),
    arrows = 2,
    free = TRUE,
    values = c(1,1,1,1),
    labels = c("VarX1","VarX2","VarResM","VarResY")),
  mxPath(           # paths a1 and c1
    from = "IncomeR",
    to = c("sEsteem","happy"),
    arrows = 1,
    free = T,
    values = c(1,1),
    labels = c("a1","c1")),
  mxPath(           # paths a2 and c2
    from = "IncomeP",
    to = c("sEsteem","happy"),
    arrows = 1,
    free = T,
    values = 1,
    labels = c("a2","c2")),
  mxPath(           # paths b
    from = "sEsteem",
    to = "happy",
    arrows = 1,
    free = T,
    values = 1,
    labels = "b"),
  mxPath(           # covariance
    from = "IncomeR",
    to = "IncomeP",
    arrows = 2,
    free = T,
    values = 0.5,
    labels = "cov"),
  mxPath(           # means and intercepts
    from = "one",
    to = c("IncomeR","IncomeP","sEsteem","happy"),
    arrows = 1,
    free = T,
    values = c(1,1,1,1),
    labels = c("meanX1","meanX2","intercM","intercY")),
  mxAlgebra(expression = a1*b, name = "a1b"),
  mxAlgebra(expression = a2*b, name = "a2b"),
  mxAlgebra(expression = a1*b+c1, name = "totalEffect1"),
  mxAlgebra(expression = a2*b+c2, name = "totalEffect2"),
  mxAlgebra(expression = a1*b+a2*b, name = "totalIE"),
  mxAlgebra(expression = a1*b+c1+a2*b+c2, name = "totalEffect"),
  mxAlgebra(expression = a1*b-c1, name = "a1b_c1"),
  mxAlgebra(expression = a2*b-c2, name = "a2b_c2"),
  mxAlgebra(expression = a1*b-a2*b, name = "a1b_a2b"),
  mxAlgebra(expression = a1*b+c1-(a2*b+c2), name = "tE1_tE2"),
  mxCI(c("a1","a2","b","c1","c2","a1b","a2b","totalEffect1","totalEffect2","totalIE","totalEffect","a1b_c1","a2b_c2","a1b_a2b","tE1_tE2"),interval = 0.95)
)

results <- mxRun(myModel, intervals = T, suppressWarnings = F)
summary(results)


bootstrap <- function(dat,Model,B=5000) {
  a1b.2 <- a2b.2 <- a3b.2 <- tE1.2 <- tE2.2 <- tIE.2 <- tE.2 <- a1b_c1.2 <- a2b_c2.2 <- a1b_a2b.2 <- tE1_tE2.2 <- NULL
  ndat <- nrow(dat)
  nn <- 1:ndat
  for (i in 1:B) {
      bSample <- data.frame(dat[sample(nn, ndat, replace = TRUE),])
      modelB <- mxModel(Model, mxData(observed = bSample, type = "raw"))
      BRes <- mxRun(modelB, silent = T, suppressWarnings = T)
      a1b.1 <- mxEval(a1b, BRes)
      a1b.2 <- cbind(a1b.2, a1b.1)
      a2b.1 <- mxEval(a2b, BRes)
      a2b.2 <- cbind(a2b.2, a2b.1)
      tE1.1 <- mxEval(totalEffect1, BRes)
      tE1.2 <- cbind(tE1.2, tE1.1)
      tE2.1 <- mxEval(totalEffect2, BRes)
      tE2.2 <- cbind(tE2.2, tE2.1)
      tIE.1 <- mxEval(totalIE, BRes)
      tIE.2 <- cbind(tIE.2, tIE.1)
      tE.1 <- mxEval(totalEffect, BRes)
      tE.2 <- cbind(tE.2, tE.1)
      a1b_c1.1 <- mxEval(a1b_c1, BRes)
      a1b_c1.2 <- cbind(a1b_c1.2, a1b_c1.1)
      a2b_c2.1 <- mxEval(a2b_c2, BRes)
      a2b_c2.2 <- cbind(a2b_c2.2, a2b_c2.1)
      a1b_a2b.1 <- mxEval(a1b_a2b, BRes)
      a1b_a2b.2 <- cbind(a1b_a2b.2, a1b_a2b.1)
      tE1_tE2.1 <- mxEval(tE1_tE2, BRes)
      tE1_tE2.2 <- cbind(tE1_tE2.2, tE1_tE2.1)
  }
  matrix(c(a1b.2,a2b.2,tE1.2,tE2.2,tIE.2,tE.2,a1b_c1.2,a2b_c2.2,a1b_a2b.2,tE1_tE2.2),B,10,
           dimnames = list(c(),c("a1b","a2b","total effect 1","total effect 2","total IE","total effect","a1b-c1","a2b-c2","a1b-a2b","tE1-tE2")))
}

BData <- bootstrap(data,myModel,B=5)
BData # VarNames: "a1b","a2b","total effect 1","total effect 2","total IE","total effect","a1b-c1","a2b-c2","a1b-a2b","tE1-tE2"

ci <- function(bData, CI = .95, deci = 3){
  lowb2 <- highb2 <- NULL
  cil <- (1-CI)/2
  cih <- 1-cil
  CIp <- CI*100
  ne <- ncol(bData)
  coli <- 0
  for (i in 1:ne){
     coli <- coli + 1
     lowb1 <- round(quantile(bData[,coli], cil),deci)
     lowb2 <- c(lowb2,lowb1)
     highb1 <- round(quantile(bData[,coli], cih),deci)
     highb2 <- c(highb2,highb1)  

  }
  bbounds <- matrix(c(lowb2,highb2),coli,2,
        dimnames = list(c("a1b","a2b","total effect 1","total effect 2","total IE","total effect","a1b-c1","a2b-c2","a1b-a2b","tE1-tE2"),
                        c("lower bound", "upper bound")))
  cat(CIp,"% bootstrap Confidence Intervals for the specific effects\n")
  return(bbounds)
}

cie <- ci(BData, CI = .99, deci = 4); cie

#### Results

round(quantile(BData[,1], c(.005, .995)),4)
round(quantile(BData[,2], c(.005, .995)),4)
round(quantile(BData[,3], c(.005, .995)),4)
round(quantile(BData[,4], c(.005, .995)),4)
round(quantile(BData[,5], c(.005, .995)),4)
round(quantile(BData[,6], c(.005, .995)),4)
round(quantile(BData[,7], c(.005, .995)),4)
round(quantile(BData[,8], c(.005, .995)),4)
round(quantile(BData[,9], c(.005, .995)),4)
round(quantile(BData[,10], c(.005, .995)),4)
