# =========================================================================================================
# Ledermann, T., & Macho, S. Assessing mediation in simple and complex models
# =========================================================================================================
#
# Code for a mediation model with two sequential mediators
# Author: Thomas Ledermann
#
# =========================================================================================================
# Data: Quality of Employment Survey (Quinn & Graham, 1977))
# "V53","V657","V785","V848" = X -> M1 -> M2 -> Y
# =========================================================================================================

#source('http://openmx.psyc.virginia.edu/getOpenMx.R')

datafile <- 'C:/Users/Data.csv'
data <- read.csv(datafile, header = TRUE, sep = ",")
head(data)
nrow(data) 

library(OpenMx)

myModel <- mxModel(name = "Mediation Model", type = "RAM", mxData(observed=data,type = "raw"),
  manifestVars = c("V53","V657","V785","V848"),
  mxPath(           # Variances
    from = c("V53","V657","V785","V848"),
    arrows = 2,
    free = TRUE,
    values = c(1,1,1,1),
    labels = c("VarX","VarResM1","VarResM2","VarResY")),
  mxPath(           # paths a and c
    from = "V53",
    to = c("V657","V785","V848"),
    arrows = 1,
    free = T,
    values = 1,
    labels = c("a1","a2","c")),
  mxPath(           # paths b12
    from = "V657",
    to = "V785",
    arrows = 1,
    free = T,
    values = 1,
    labels = "b12"),
  mxPath(           # paths b1 and b2
    from = c("V657","V785"),
    to = "V848",
    arrows = 1,
    free = T,
    values = 1,
    labels = c("b1","b2")),
  mxPath(           # means and intercepts
    from = "one",
    to = c("V53","V657","V785","V848"),
    arrows = 1,
    free = T,
    values = c(1,1,1,1),
    labels = c("meanX","intercM1","intercM2","intercY")),
  mxAlgebra(expression = a1*b1, name = "a1b1"),
  mxAlgebra(expression = a2*b2, name = "a2b2"),
  mxAlgebra(expression = a1*b12*b2, name = "a1b12b2"),
  mxAlgebra(expression = a1*b12*b2+a1*b1+a2*b2, name = "totalIE"),
  mxAlgebra(expression = a1*b12*b2+a1*b1+a2*b2+c, name = "totalEffect"),
  mxAlgebra(expression = a1*b1-c, name = "a1b1_c"),
  mxAlgebra(expression = a2*b2-c, name = "a2b2_c"),
  mxAlgebra(expression = a1*b12*b2-c, name = "a1b12b2_c"),
  mxAlgebra(expression = a1*b12*b2+a1*b1+a2*b2-c, name = "totalIE_c"),
  mxCI(c("a1","a2","b12","b1","b2","c","a1b1","a2b2","a1b12b2","totalIE","totalEffect","a1b1_c","a2b2_c","a1b12b2_c","totalIE_c"),interval = 0.95)
)

results <- mxRun(myModel, intervals = T, suppressWarnings = F)
summary(results)


bootstrap <- function(dat,Model,B=5000) {
  a1b1.2 <- a2b2.2 <- a1b12b2.2 <- tIE.2 <- tE.2 <- a1b1_c.2 <- a2b2_c.2 <- a1b12b2_c.2 <- tIE_c.2 <- NULL
  ndat <- nrow(dat)
  nn <- 1:ndat
  for (i in 1:B) {
      bSample <- data.frame(dat[sample(nn, ndat, replace = TRUE),])
      modelB <- mxModel(Model, mxData(observed = bSample, type = "raw"))
      BRes <- mxRun(modelB, silent = T, suppressWarnings = T)
      a1b1.1 <- mxEval(a1b1, BRes)
      a1b1.2 <- cbind(a1b1.2, a1b1.1)
      a2b2.1 <- mxEval(a2b2, BRes)
      a2b2.2 <- cbind(a2b2.2, a2b2.1)
      a1b12b2.1 <- mxEval(a1b12b2, BRes)
      a1b12b2.2 <- cbind(a1b12b2.2, a1b12b2.1)
      tIE.1 <- mxEval(totalIE, BRes)
      tIE.2 <- cbind(tIE.2, tIE.1)
      tE.1 <- mxEval(totalEffect, BRes)
      tE.2 <- cbind(tE.2, tE.1)
      a1b1_c.1 <- mxEval(a1b1_c, BRes)
      a1b1_c.2 <- cbind(a1b1_c.2, a1b1_c.1)
      a2b2_c.1 <- mxEval(a2b2_c, BRes)
      a2b2_c.2 <- cbind(a2b2_c.2, a1b1_c.1)
      a1b12b2_c.1 <- mxEval(a1b12b2_c, BRes)
      a1b12b2_c.2 <- cbind(a1b12b2_c.2, a1b1_c.1)
      tIE_c.1 <- mxEval(totalIE_c, BRes)
      tIE_c.2 <- cbind(tIE_c.2, tIE_c.1)
  }
  matrix(c(a1b1.2,a2b2.2,a1b12b2.2,tIE.2,tE.2,a1b1_c.2,a2b2_c.2,a1b12b2_c.2,tIE_c.2),B,9,
           dimnames = list(c(),c("a1b1","a2b2","a1b12b2","total IE","total effect","a1b1-c","a2b2-c","a1b12b2-c","tIE-c")))
}

BData <- bootstrap(data,myModel,B=5000)
BData # VarNames: "a1b1","a2b2","a1b12b2","total IE","total effect","a1b1-c","a2b2-c","a1b12b2-c","tIE-c"

# write.csv(BData,"C:/Users/Owner/Documents/DataAna/ICPSR_AssessingMediation/QualityOfEmploymentSurvey_1977/R/DataBootstrap.csv",na="",row.names=FALSE) 

ci <- function(bData, CI = .95, deci = 3){
  lowb2 <- highb2 <- NULL
  cil <- (1-CI)/2
  cih <- 1-cil
  CIp <- CI*100
  ne <- ncol(bData)
  coli <- 0
  for (i in 1:ne){
     coli <- coli + 1
     lowb1 <- round(quantile(bData[,coli], cil),deci)
     lowb2 <- c(lowb2,lowb1)
     highb1 <- round(quantile(bData[,coli], cih),deci)
     highb2 <- c(highb2,highb1)  

  }
  bbounds <- matrix(c(lowb2,highb2),coli,2,
        dimnames = list(c("a1b1","a2b2","a1b12b2","total IE","total effect","a1b1-c","a2b2-c","a1b12b2-c","tIE-c"),
                        c("lower bound", "upper bound")))
  cat(CIp,"% bootstrap Confidence Intervals for the specific effects\n")
  return(bbounds)
}

cie <- ci(BData, CI = .95, deci = 4); cie

#### Results

round(quantile(BData[,1], c(.025, .975)),4)
round(quantile(BData[,2], c(.025, .975)),4)
round(quantile(BData[,3], c(.025, .975)),4)
round(quantile(BData[,4], c(.025, .975)),4)
round(quantile(BData[,5], c(.025, .975)),4)
round(quantile(BData[,6], c(.025, .975)),4)
round(quantile(BData[,7], c(.025, .975)),4)
round(quantile(BData[,8], c(.025, .975)),4)
round(quantile(BData[,9], c(.025, .975)),4)
